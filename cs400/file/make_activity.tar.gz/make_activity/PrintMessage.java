public class PrintMessage {

	public static void main(String[] args) {
		// TODO: replace the string with your @wisc.edu email
		String studentEmail = "<replace with your @wisc.edu email>";
		System.out.print("This demo was written by ");
		System.out.print(studentEmail);
		System.out.println(".");
	}

}
