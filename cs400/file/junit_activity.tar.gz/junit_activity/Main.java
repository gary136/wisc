public class Main {

    public static void main(String[] args) {
        System.out.println("FIXME: Do something with the MyList class");
    }

}
