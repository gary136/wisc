/* 
 * Main class for CS400: FirstGitActivity Spring (2021).
 * Your Name: Lee Hung Ting
 * Your Email: hlee864@wisc.edu 
 * Your Login: hlee864
 * 
 * This class prints out a silly computer science joke.
 */
public class Main {
    public static void main(String[] args) {
	System.out.println("Why did two foos walks into a bar?");
    System.out.println("To say \"Hello World\" to their friend Baz.");
    }
}
