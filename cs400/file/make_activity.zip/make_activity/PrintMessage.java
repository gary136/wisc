public class PrintMessage {

	public static void main(String[] args) {
		// TODO: replace the string with your @wisc.edu email
		String studentEmail = "hlee864@wisc.edu";
		System.out.print("This demo was written by ");
		System.out.print(studentEmail);
		System.out.println(".");
	}

}
