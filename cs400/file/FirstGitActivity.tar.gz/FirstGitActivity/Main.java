/* 
 * Main class for CS400: FirstGitActivity Spring (2021).
 * Your Name: <enter your first and last name here>
 * Your Email: <enter your @wisc.edu email address here> 
 * Your Login: <enter your cs username here>
 * 
 * This class prints out a silly computer science joke.
 */
public class Main {
    public static void main(String[] args) {
	System.out.println("Why did two foos walks into a bar?");
    }
}
